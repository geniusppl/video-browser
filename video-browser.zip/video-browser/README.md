# 视频浏览器（1.1：基础版 + 全屏播放器）

个人使用的安卓浏览器：Kotlin + Jetpack Compose + 系统 WebView。
提示词一：基础浏览功能。提示词二：全屏视频播放器（Media3 ExoPlayer）。
不含视频增强、嗅探、下载。

## 功能

1. **地址栏**：输入网址直接打开；输入关键词用百度搜索；加载时显示进度条；显示当前页面网址
2. **底部工具栏**：后退、前进、刷新、标签页数量（点数字打开标签页列表）
3. **多标签页**：新建、切换、关闭；每个标签页各自独立（各自的 WebView、前进后退历史）
4. **历史记录**：自动记录（标题、网址、时间），可查看、搜索、单条删除、全部清空，Room 存储，重启后仍在
5. **书签**：地址栏星标收藏 / 取消收藏，可查看、删除，重启后仍在
6. **返回键**：先退子页面 → 再退视频全屏 → 再退网页 → 最后退出应用
7. **网页视频全屏**：网页自带的全屏按钮能正常全屏和退出（WebChromeClient 的 onShowCustomView / onHideCustomView）
8. 已开启 JavaScript 和 DOM 存储

## 提示词二：全屏视频播放器（新增）

入口：地址栏右上角菜单 → “播放视频”。
1. **播放**：粘贴 mp4 / m3u8（HLS）/ mpd（DASH）地址播放，或“选择本地视频”播手机里的视频；Media3 ExoPlayer，横屏优先（左右横屏间随手机旋转）
2. **控制**：播放/暂停、进度条、当前时间与总时长、返回、标题；3 秒无操作自动隐藏控制层，点一下画面重新显示
3. **倍速**：0.5、0.75、1.0、1.25、1.5、2.0、3.0
4. **手势**：左右滑调进度（显示预览时间）、左侧上下滑调亮度、右侧上下滑调音量、双击暂停/播放、长按两倍速（松开恢复）
5. **锁屏**：点锁屏按钮隐藏控件并屏蔽触摸，右上角点锁图标解锁
6. **画面比例**：适应、填充、拉伸、16:9、4:3
7. **记忆位置**：退出/暂停时保存进度（Room 的 playback_positions 表，数据库 v1→v2 迁移，历史书签保留），再播同一视频自动从上次位置继续并提示；播放入口页有“继续播放”列表
8. **出错**：地址失效或网络错误时显示明确提示和“重试”按钮，不闪退

## 项目结构

```
video-browser/
├── settings.gradle.kts          # 只含 app 一个模块
├── build.gradle.kts             # 顶层构建文件（插件声明）
├── gradle.properties
├── gradle/libs.versions.toml    # 版本目录：AGP / Kotlin / Compose / Room 等
├── .github/workflows/android.yml# 云编译工作流
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml  # INTERNET 权限，MainActivity（configChanges 保留标签页）
        ├── res/                 # 字符串、主题、启动图标
        └── java/com/breeze/videobrowser/
            ├── MainActivity.kt          # 入口：建数据库、建 ViewModel、显示主界面
            ├── ui/
            │   ├── BrowserScreen.kt     # 主界面：地址栏 + 网页区 + 底部工具栏 + 返回键
            │   ├── AddressBar.kt        # 地址栏：输入、收藏星标、菜单（历史/书签/新建标签）
            │   ├── TabsScreen.kt        # 标签页列表：卡片式，点卡片切换，叉关闭
            │   ├── HistoryScreen.kt     # 历史记录：搜索、点开、删除、清空
            │   ├── BookmarkScreen.kt    # 书签：点开、删除
            │   ├── TimeFormat.kt        # 时间戳格式化
            │   └── theme/               # Material3 主题（青色系，跟随系统深浅色）
            ├── webview/
            │   ├── WebViewManager.kt    # 各标签页的 WebView 管理、历史记录、全屏处理
            │   └── UrlResolver.kt       # 地址栏输入 → 网址 / 百度搜索
            ├── tabs/
            │   └── BrowserViewModel.kt  # 标签页状态：新建、切换、关闭、标题/进度/前进后退
            ├── player/
            │   └── VideoPlayerActivity.kt # 全屏播放页：Media3、倍速、手势、锁屏、画面比例、记忆位置
            └── data/
                ├── AppDatabase.kt       # Room：HistoryItem、Bookmark、PlaybackPosition、DAO、Database（v2）
                ├── BrowserRepository.kt # 历史、书签与播放记录的数据入口
                └── DatabaseProvider.kt  # 数据库单例（video_browser.db，v1→v2 迁移）
```

## 技术栈

- 语言 Kotlin 2.0.21；minSdk 26（安卓 8.0），targetSdk 34，compileSdk 34
- 界面 Jetpack Compose（BOM 2024.09.00，Material3）
- 网页内核：系统 WebView（AndroidView 承载）
- 存储：Room 2.6.1（KSP 生成代码）
- 播放器：Media3 1.3.1（exoplayer + exoplayer-hls + exoplayer-dash + ui）
- 构建：Gradle 8.9（Kotlin DSL + libs.versions.toml），AGP 8.7.3，JDK 17
- Git 管理

## 云编译（没有电脑时用这套）

仓库根目录放 `video-browser.zip`（顶层文件夹为 `video-browser/`，排除 `.git`、`.github`、`build` 目录），
`.github/workflows/android.yml` 负责：解压 → JDK 17 → 安装 Android SDK 34 → `gradle assembleDebug` → 上传 `app-debug` 构件。
推送到 main 分支即触发构建，产物在 Actions 运行页的 Artifacts 里下载。

打包命令（从 `~/workspace` 执行）：

```bash
zip -r your_files/video-browser.zip video-browser \
  -x "video-browser/.git*" "video-browser/.github*" "video-browser/**/build/*"
```

## Android Studio 里运行（有电脑时）

1. 打开 Android Studio → Open → 选择 `video-browser` 目录 → 等 Gradle 同步完成
2. 手机打开“开发者选项 → USB 调试”，用数据线连电脑，手机上点“允许 USB 调试”
3. Android Studio 顶部选你的手机 → 点绿色三角运行
4. 手机上打开“视频浏览器”，即完成
