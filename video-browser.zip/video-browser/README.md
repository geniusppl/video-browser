# 视频浏览器（基础版）

个人使用的安卓浏览器：Kotlin + Jetpack Compose + 系统 WebView。
提示词一的范围：基础浏览功能，不含播放器、视频增强、嗅探、下载。

## 功能

1. **地址栏**：输入网址直接打开；输入关键词用百度搜索；加载时显示进度条；显示当前页面网址
2. **底部工具栏**：后退、前进、刷新、标签页数量（点数字打开标签页列表）
3. **多标签页**：新建、切换、关闭；每个标签页各自独立（各自的 WebView、前进后退历史）
4. **历史记录**：自动记录（标题、网址、时间），可查看、搜索、单条删除、全部清空，Room 存储，重启后仍在
5. **书签**：地址栏星标收藏 / 取消收藏，可查看、删除，重启后仍在
6. **返回键**：先退子页面 → 再退视频全屏 → 再退网页 → 最后退出应用
7. **网页视频全屏**：网页自带的全屏按钮能正常全屏和退出（WebChromeClient 的 onShowCustomView / onHideCustomView）
8. 已开启 JavaScript 和 DOM 存储

## 项目结构

```
video-browser/
├── settings.gradle.kts          # 只含 app 一个模块
├── build.gradle.kts             # 顶层构建文件（插件声明）
├── gradle.properties
├── gradle/libs.versions.toml    # 版本目录：AGP / Kotlin / Compose / Room 等
├── .github/workflows/android.yml# 云编译工作流
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml  # INTERNET 权限，MainActivity（configChanges 保留标签页）
        ├── res/                 # 字符串、主题、启动图标
        └── java/com/breeze/videobrowser/
            ├── MainActivity.kt          # 入口：建数据库、建 ViewModel、显示主界面
            ├── ui/
            │   ├── BrowserScreen.kt     # 主界面：地址栏 + 网页区 + 底部工具栏 + 返回键
            │   ├── AddressBar.kt        # 地址栏：输入、收藏星标、菜单（历史/书签/新建标签）
            │   ├── TabsScreen.kt        # 标签页列表：卡片式，点卡片切换，叉关闭
            │   ├── HistoryScreen.kt     # 历史记录：搜索、点开、删除、清空
            │   ├── BookmarkScreen.kt    # 书签：点开、删除
            │   ├── TimeFormat.kt        # 时间戳格式化
            │   └── theme/               # Material3 主题（青色系，跟随系统深浅色）
            ├── webview/
            │   ├── WebViewManager.kt    # 各标签页的 WebView 管理、历史记录、全屏处理
            │   └── UrlResolver.kt       # 地址栏输入 → 网址 / 百度搜索
            ├── tabs/
            │   └── BrowserViewModel.kt  # 标签页状态：新建、切换、关闭、标题/进度/前进后退
            └── data/
                ├── AppDatabase.kt       # Room：HistoryItem、Bookmark、DAO、Database
                ├── BrowserRepository.kt # 历史与书签的数据入口
                └── DatabaseProvider.kt  # 数据库单例（video_browser.db）
```

## 技术栈

- 语言 Kotlin 2.0.21；minSdk 26（安卓 8.0），targetSdk 34，compileSdk 34
- 界面 Jetpack Compose（BOM 2024.09.00，Material3）
- 网页内核：系统 WebView（AndroidView 承载）
- 存储：Room 2.6.1（KSP 生成代码）
- 构建：Gradle 8.9（Kotlin DSL + libs.versions.toml），AGP 8.7.3，JDK 17
- Git 管理

## 云编译（没有电脑时用这套）

仓库根目录放 `video-browser.zip`（顶层文件夹为 `video-browser/`，排除 `.git`、`.github`、`build` 目录），
`.github/workflows/android.yml` 负责：解压 → JDK 17 → 安装 Android SDK 34 → `gradle assembleDebug` → 上传 `app-debug` 构件。
推送到 main 分支即触发构建，产物在 Actions 运行页的 Artifacts 里下载。

打包命令（从 `~/workspace` 执行）：

```bash
zip -r your_files/video-browser.zip video-browser \
  -x "video-browser/.git*" "video-browser/.github*" "video-browser/**/build/*"
```

## Android Studio 里运行（有电脑时）

1. 打开 Android Studio → Open → 选择 `video-browser` 目录 → 等 Gradle 同步完成
2. 手机打开“开发者选项 → USB 调试”，用数据线连电脑，手机上点“允许 USB 调试”
3. Android Studio 顶部选你的手机 → 点绿色三角运行
4. 手机上打开“视频浏览器”，即完成
