package com.breeze.videobrowser.ui

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** 时间戳格式化为 MM-dd HH:mm，例如 11-04 17:30 */
fun formatTime(timestamp: Long): String {
    return SimpleDateFormat("MM-dd HH:mm", Locale.getDefault()).format(Date(timestamp))
}
