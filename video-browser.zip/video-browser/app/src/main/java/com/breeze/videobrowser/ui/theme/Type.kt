package com.breeze.videobrowser.ui.theme

import androidx.compose.material3.Typography

// 使用 Material3 默认字体
val Typography = Typography()
