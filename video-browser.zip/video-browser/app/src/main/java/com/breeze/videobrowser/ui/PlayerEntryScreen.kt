package com.breeze.videobrowser.ui

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.breeze.videobrowser.data.BrowserRepository
import com.breeze.videobrowser.data.PlaybackPosition
import com.breeze.videobrowser.player.VideoPlayerActivity
import com.breeze.videobrowser.player.formatPlayerTime

/** 播放入口页（提示词二第 9 项）：粘贴视频地址播放，或从手机里选本地视频播放 */
@Composable
fun PlayerEntryScreen(
    repository: BrowserRepository,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    var urlText by remember { mutableStateOf("") }
    var tip by remember { mutableStateOf("") }
    val history by repository.getPlaybackPositions().collectAsState(initial = emptyList())

    // 选本地视频：系统文件选择器，只显示视频类型
    val pickVideo = rememberLauncherForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri == null) return@rememberLauncherForActivityResult
        // 保留读取权限，播放页退出重进也能接着用
        try {
            context.contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: Exception) {
            // 部分机型不支持持久授权也不影响本次播放
        }
        val name = localDisplayName(context, uri)
        context.startActivity(
            VideoPlayerActivity.createIntent(context, uri.toString(), name, true)
        )
    }

    fun playUrl(raw: String) {
        val url = raw.trim()
        if (url.isBlank()) {
            tip = "先粘贴一个视频地址"
            return
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            tip = "地址要以 http:// 或 https:// 开头"
            return
        }
        val title = Uri.parse(url).lastPathSegment ?: url
        tip = ""
        context.startActivity(
            VideoPlayerActivity.createIntent(context, url, title, false)
        )
    }

    Column(modifier = Modifier.fillMaxSize()) {
        // 顶部标题栏
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 4.dp)
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "返回")
            }
            Text(text = "播放视频", fontSize = 18.sp)
        }

        LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            item {
                Text("粘贴视频地址播放", fontSize = 15.sp)
                Spacer(modifier = Modifier.height(8.dp))
                TextField(
                    value = urlText,
                    onValueChange = { urlText = it },
                    placeholder = { Text("粘贴 mp4 / m3u8 / mpd 地址") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row {
                    Button(onClick = { playUrl(urlText) }) {
                        Icon(Icons.Filled.PlayArrow, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("播放")
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    OutlinedButton(onClick = { pickVideo.launch("video/*") }) {
                        Icon(Icons.Filled.FolderOpen, contentDescription = null)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("选择本地视频")
                    }
                }
                if (tip.isNotEmpty()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = tip, fontSize = 14.sp)
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "支持 mp4、m3u8（HLS）、mpd（DASH）地址和手机本地视频。播放中左右滑调进度，左侧上下滑调亮度，右侧上下滑调音量，双击暂停/播放，长按两倍速。",
                    fontSize = 13.sp
                )
                Spacer(modifier = Modifier.height(16.dp))
                Text("继续播放", fontSize = 15.sp)
                Spacer(modifier = Modifier.height(8.dp))
                if (history.isEmpty()) {
                    Text("还没有看过的视频，播过一半退出的视频会留在这里。", fontSize = 13.sp)
                }
            }
            // 继续播放列表：点一个就从上次位置继续
            items(history) { item: PlaybackPosition ->
                Card(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                    onClick = {
                        context.startActivity(
                            VideoPlayerActivity.createIntent(
                                context, item.url, item.title, false
                            )
                        )
                    }
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(text = item.title, fontSize = 14.sp, maxLines = 1)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "上次看到 ${formatPlayerTime(item.positionMs)}" +
                                if (item.durationMs > 0) " / ${formatPlayerTime(item.durationMs)}" else "",
                            fontSize = 13.sp
                        )
                    }
                }
            }
            item { Spacer(modifier = Modifier.height(16.dp)) }
        }
    }
}

/** 读本地视频的文件名 */
private fun localDisplayName(context: Context, uri: Uri): String {
    if (uri.scheme != "content") return uri.lastPathSegment.orEmpty()
    return try {
        context.contentResolver.query(
            uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (idx >= 0) cursor.getString(idx) ?: uri.lastPathSegment.orEmpty()
                else uri.lastPathSegment.orEmpty()
            } else uri.lastPathSegment.orEmpty()
        } ?: uri.lastPathSegment.orEmpty()
    } catch (_: Exception) {
        uri.lastPathSegment.orEmpty()
    }
}
