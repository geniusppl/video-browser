package com.breeze.videobrowser.data

import kotlinx.coroutines.flow.Flow

/** 历史与书签的数据入口：界面只通过它读写数据库 */
class BrowserRepository(
    private val historyDao: HistoryDao,
    private val bookmarkDao: BookmarkDao,
    private val playbackDao: PlaybackDao? = null
) {
    /** 全部历史记录 */
    fun getHistory(): Flow<List<HistoryItem>> = historyDao.getAll()

    /** 搜索历史；空关键词返回全部 */
    fun searchHistory(query: String): Flow<List<HistoryItem>> {
        return if (query.isBlank()) historyDao.getAll() else historyDao.search(query)
    }

    /** 记一条历史 */
    suspend fun addHistory(url: String, title: String) {
        historyDao.insert(HistoryItem(url, title, System.currentTimeMillis()))
    }

    /** 删除一条历史 */
    suspend fun deleteHistory(url: String) {
        historyDao.delete(url)
    }

    /** 清空全部历史 */
    suspend fun clearHistory() {
        historyDao.deleteAll()
    }

    /** 全部书签 */
    fun getBookmarks(): Flow<List<Bookmark>> = bookmarkDao.getAll()

    /** 监听某网址是否已收藏 */
    fun observeBookmark(url: String): Flow<Bookmark?> = bookmarkDao.observe(url)

    /** 添加书签 */
    suspend fun addBookmark(url: String, title: String) {
        bookmarkDao.insert(Bookmark(url, title, System.currentTimeMillis()))
    }

    /** 删除书签 */
    suspend fun removeBookmark(url: String) {
        bookmarkDao.delete(url)
    }

    /** 保存播放进度（退出 / 暂停时调用）；播完或只剩几秒时不保存，下次从头播 */
    suspend fun savePlaybackPosition(url: String, title: String, positionMs: Long, durationMs: Long) {
        val dao = playbackDao ?: return
        if (url.isBlank() || positionMs < 5_000) return
        if (durationMs > 0 && positionMs > durationMs - 5_000) {
            dao.delete(url)
            return
        }
        dao.insert(PlaybackPosition(url, title, positionMs, durationMs, System.currentTimeMillis()))
    }

    /** 查某一个视频的保存进度，没有返回 null */
    suspend fun getPlaybackPosition(url: String): PlaybackPosition? {
        return playbackDao?.get(url)
    }

    /** 全部播放记录（“继续播放”列表用） */
    fun getPlaybackPositions(): Flow<List<PlaybackPosition>> {
        return playbackDao?.getAll() ?: kotlinx.coroutines.flow.flowOf(emptyList())
    }
}
