package com.breeze.videobrowser.data

import kotlinx.coroutines.flow.Flow

/** 历史与书签的数据入口：界面只通过它读写数据库 */
class BrowserRepository(
    private val historyDao: HistoryDao,
    private val bookmarkDao: BookmarkDao
) {
    /** 全部历史记录 */
    fun getHistory(): Flow<List<HistoryItem>> = historyDao.getAll()

    /** 搜索历史；空关键词返回全部 */
    fun searchHistory(query: String): Flow<List<HistoryItem>> {
        return if (query.isBlank()) historyDao.getAll() else historyDao.search(query)
    }

    /** 记一条历史 */
    suspend fun addHistory(url: String, title: String) {
        historyDao.insert(HistoryItem(url, title, System.currentTimeMillis()))
    }

    /** 删除一条历史 */
    suspend fun deleteHistory(url: String) {
        historyDao.delete(url)
    }

    /** 清空全部历史 */
    suspend fun clearHistory() {
        historyDao.deleteAll()
    }

    /** 全部书签 */
    fun getBookmarks(): Flow<List<Bookmark>> = bookmarkDao.getAll()

    /** 监听某网址是否已收藏 */
    fun observeBookmark(url: String): Flow<Bookmark?> = bookmarkDao.observe(url)

    /** 添加书签 */
    suspend fun addBookmark(url: String, title: String) {
        bookmarkDao.insert(Bookmark(url, title, System.currentTimeMillis()))
    }

    /** 删除书签 */
    suspend fun removeBookmark(url: String) {
        bookmarkDao.delete(url)
    }
}
