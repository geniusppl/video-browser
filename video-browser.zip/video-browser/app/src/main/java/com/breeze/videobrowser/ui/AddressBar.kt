package com.breeze.videobrowser.ui

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.outlined.StarBorder
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp

/** 顶部地址栏：显示当前网址、可输入、可收藏、可打开菜单 */
@Composable
fun AddressBar(
    currentUrl: String,
    isBookmarked: Boolean,
    onNavigate: (String) -> Unit,
    onToggleBookmark: () -> Unit,
    onHistoryClick: () -> Unit,
    onBookmarksClick: () -> Unit,
    onNewTabClick: () -> Unit,
    onPlayerClick: () -> Unit = {}
) {
    var text by remember { mutableStateOf("") }
    var editing by remember { mutableStateOf(false) }
    var menuExpanded by remember { mutableStateOf(false) }
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current

    Row(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        TextField(
            value = if (editing) text else currentUrl,
            onValueChange = { text = it },
            placeholder = { Text("搜索或输入网址") },
            singleLine = true,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Go),
            keyboardActions = KeyboardActions(onGo = {
                onNavigate(text)
                editing = false
                focusManager.clearFocus()
                keyboardController?.hide()
            }),
            colors = TextFieldDefaults.colors(
                focusedIndicatorColor = Color.Transparent,
                unfocusedIndicatorColor = Color.Transparent
            ),
            modifier = Modifier
                .weight(1f)
                .onFocusChanged { state ->
                    if (state.isFocused) {
                        // 点进输入框时，把当前网址填进去方便编辑
                        editing = true
                        text = currentUrl
                    } else {
                        editing = false
                    }
                }
        )
        // 收藏按钮：已收藏显示实心星
        IconButton(onClick = onToggleBookmark) {
            Icon(
                imageVector = if (isBookmarked) Icons.Filled.Star else Icons.Outlined.StarBorder,
                contentDescription = if (isBookmarked) "取消收藏" else "收藏"
            )
        }
        // 菜单按钮
        Box {
            IconButton(onClick = { menuExpanded = true }) {
                Icon(Icons.Default.MoreVert, contentDescription = "菜单")
            }
            DropdownMenu(
                expanded = menuExpanded,
                onDismissRequest = { menuExpanded = false }
            ) {
                DropdownMenuItem(
                    text = { Text("历史记录") },
                    onClick = { menuExpanded = false; onHistoryClick() }
                )
                DropdownMenuItem(
                    text = { Text("书签") },
                    onClick = { menuExpanded = false; onBookmarksClick() }
                )
                DropdownMenuItem(
                    text = { Text("新建标签页") },
                    onClick = { menuExpanded = false; onNewTabClick() }
                )
                DropdownMenuItem(
                    text = { Text("播放视频") },
                    onClick = { menuExpanded = false; onPlayerClick() }
                )
            }
        }
    }
}
