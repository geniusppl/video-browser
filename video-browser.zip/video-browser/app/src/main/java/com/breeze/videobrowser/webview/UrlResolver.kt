package com.breeze.videobrowser.webview

import java.net.URLEncoder

/**
 * 把地址栏输入转成要打开的网址：
 * - 像网址（带 http/https，或含点且无空格）→ 直接打开，缺协议时补 https://
 * - 其他 → 百度搜索
 */
fun resolveInputToUrl(input: String): String {
    val trimmed = input.trim()
    if (trimmed.isEmpty()) return ""
    val hasScheme = trimmed.startsWith("http://") || trimmed.startsWith("https://")
    val looksLikeUrl = hasScheme || (trimmed.contains(".") && !trimmed.contains(" "))
    return if (looksLikeUrl) {
        if (hasScheme) trimmed else "https://$trimmed"
    } else {
        "https://www.baidu.com/s?wd=" + URLEncoder.encode(trimmed, "UTF-8")
    }
}
