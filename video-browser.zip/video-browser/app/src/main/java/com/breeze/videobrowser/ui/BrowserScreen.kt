package com.breeze.videobrowser.ui

import android.app.Activity
import android.widget.FrameLayout
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.breeze.videobrowser.data.BrowserRepository
import com.breeze.videobrowser.tabs.BrowserViewModel
import com.breeze.videobrowser.webview.WebViewManager
import kotlinx.coroutines.launch

/** 界面状态：浏览器主页 / 标签页列表 / 历史 / 书签 / 播放入口 */
private enum class Screen {
    BROWSER, TABS, HISTORY, BOOKMARKS, PLAYER
}

/** 浏览器主界面：地址栏 + 网页区域 + 底部工具栏，子页面以覆盖层显示 */
@Composable
fun BrowserScreen(
    viewModel: BrowserViewModel,
    repository: BrowserRepository
) {
    val context = LocalContext.current
    val activity = context as Activity
    val scope = rememberCoroutineScope()

    // 各标签页的 WebView 管理器（随界面创建，随界面销毁）
    var isFullscreen by remember { mutableStateOf(false) }
    val manager = remember {
        WebViewManager(context, viewModel, repository, scope) { fullscreen ->
            isFullscreen = fullscreen
        }
    }
    // 界面销毁时销毁 WebView，避免内存泄漏
    DisposableEffect(manager) {
        onDispose { manager.destroy() }
    }

    val tabs by viewModel.tabs.collectAsState()
    val currentTabId by viewModel.currentTabId.collectAsState()
    val currentTab = tabs.find { it.id == currentTabId } ?: tabs.firstOrNull()
    val currentUrl = currentTab?.url.orEmpty()

    var screen by remember { mutableStateOf(Screen.BROWSER) }

    // 当前页面是否已收藏
    val bookmarkFlow = remember(currentUrl) { repository.observeBookmark(currentUrl) }
    val bookmarked by bookmarkFlow.collectAsState(initial = null)

    // 返回键：先退子页面 → 再退视频全屏 → 再退网页 → 最后退出应用
    BackHandler {
        when {
            screen != Screen.BROWSER -> screen = Screen.BROWSER
            isFullscreen -> manager.hideCustomView()
            manager.currentWebView()?.canGoBack() == true -> manager.currentWebView()?.goBack()
            else -> activity.finish()
        }
    }

    Box(modifier = Modifier.fillMaxSize()) {
        Column(modifier = Modifier.fillMaxSize()) {
            // 全屏时隐藏地址栏和工具栏
            if (!isFullscreen) {
                AddressBar(
                    currentUrl = currentUrl,
                    isBookmarked = bookmarked != null && currentUrl.isNotEmpty(),
                    onNavigate = { manager.navigateCurrent(it) },
                    onToggleBookmark = {
                        val tab = viewModel.currentTab ?: return@AddressBar
                        if (tab.url.isBlank()) return@AddressBar
                        if (bookmarked != null) {
                            scope.launch { repository.removeBookmark(tab.url) }
                        } else {
                            scope.launch { repository.addBookmark(tab.url, tab.title) }
                        }
                    },
                    onHistoryClick = { screen = Screen.HISTORY },
                    onBookmarksClick = { screen = Screen.BOOKMARKS },
                    onNewTabClick = { viewModel.newTab() },
                    onPlayerClick = { screen = Screen.PLAYER }
                )
                // 加载进度条
                val progress = currentTab?.progress ?: 100
                if (progress < 100) {
                    LinearProgressIndicator(
                        progress = { progress / 100f },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            // 网页区域：一个 AndroidView 容器，切换标签时只换里面的 WebView
            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                if (currentTab != null) {
                    AndroidView(
                        factory = { ctx ->
                            FrameLayout(ctx).apply {
                                addView(manager.getWebView(currentTab))
                            }
                        },
                        update = { container ->
                            val webView = manager.getWebView(currentTab)
                            if (container.childCount == 0 || container.getChildAt(0) !== webView) {
                                container.removeAllViews()
                                container.addView(webView)
                            }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                }
            }

            // 底部工具栏（全屏时隐藏）
            if (!isFullscreen) {
                BottomToolbar(
                    canGoBack = currentTab?.canGoBack == true,
                    canGoForward = currentTab?.canGoForward == true,
                    tabCount = tabs.size,
                    onBack = { manager.currentWebView()?.goBack() },
                    onForward = { manager.currentWebView()?.goForward() },
                    onRefresh = { manager.currentWebView()?.reload() },
                    onTabsClick = { screen = Screen.TABS }
                )
            }
        }

        // 子页面覆盖在浏览器之上
        when (screen) {
            Screen.TABS -> TabsScreen(
                tabs = tabs,
                currentTabId = currentTabId,
                onSwitch = { id ->
                    viewModel.switchTab(id)
                    screen = Screen.BROWSER
                },
                onClose = { id ->
                    viewModel.closeTab(id)
                    manager.removeTabWebView(id)
                },
                onNewTab = {
                    viewModel.newTab()
                    screen = Screen.BROWSER
                },
                onBack = { screen = Screen.BROWSER }
            )
            Screen.HISTORY -> HistoryScreen(
                repository = repository,
                onOpenUrl = { url ->
                    val tab = viewModel.currentTab
                    if (tab != null) manager.openUrlInTab(tab, url)
                    screen = Screen.BROWSER
                },
                onBack = { screen = Screen.BROWSER }
            )
            Screen.BOOKMARKS -> BookmarkScreen(
                repository = repository,
                onOpenUrl = { url ->
                    val tab = viewModel.currentTab
                    if (tab != null) manager.openUrlInTab(tab, url)
                    screen = Screen.BROWSER
                },
                onBack = { screen = Screen.BROWSER }
            )
            Screen.PLAYER -> PlayerEntryScreen(
                repository = repository,
                onBack = { screen = Screen.BROWSER }
            )
            Screen.BROWSER -> {}
        }
    }
}

/** 底部工具栏：后退、前进、刷新、标签页数量 */
@Composable
private fun BottomToolbar(
    canGoBack: Boolean,
    canGoForward: Boolean,
    tabCount: Int,
    onBack: () -> Unit,
    onForward: () -> Unit,
    onRefresh: () -> Unit,
    onTabsClick: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceEvenly,
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onClick = onBack, enabled = canGoBack) {
            Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "后退")
        }
        IconButton(onClick = onForward, enabled = canGoForward) {
            Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "前进")
        }
        IconButton(onClick = onRefresh) {
            Icon(Icons.Default.Refresh, contentDescription = "刷新")
        }
        // 标签页数量按钮：方框里显示数字
        IconButton(onClick = onTabsClick) {
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .border(1.5.dp, MaterialTheme.colorScheme.onSurface, RoundedCornerShape(4.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = tabCount.toString(),
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        }
    }
}
