package com.breeze.videobrowser

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.lifecycle.ViewModelProvider
import com.breeze.videobrowser.data.BrowserRepository
import com.breeze.videobrowser.data.DatabaseProvider
import com.breeze.videobrowser.tabs.BrowserViewModel
import com.breeze.videobrowser.tabs.BrowserViewModelFactory
import com.breeze.videobrowser.ui.BrowserScreen
import com.breeze.videobrowser.ui.theme.VideoBrowserTheme

class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // 数据库与仓库（单例）
        val database = DatabaseProvider.get(applicationContext)
        val repository = BrowserRepository(database.historyDao(), database.bookmarkDao())
        val viewModel = ViewModelProvider(this, BrowserViewModelFactory(repository))[BrowserViewModel::class.java]

        setContent {
            VideoBrowserTheme {
                BrowserScreen(viewModel = viewModel, repository = repository)
            }
        }
    }
}
