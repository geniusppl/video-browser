package com.breeze.videobrowser.data

import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow

/** 历史记录：网址是主键，同一网址只保留最新一条 */
@Entity(tableName = "history")
data class HistoryItem(
    @PrimaryKey val url: String,
    val title: String,
    val timestamp: Long
)

/** 书签：网址是主键 */
@Entity(tableName = "bookmarks")
data class Bookmark(
    @PrimaryKey val url: String,
    val title: String,
    val timestamp: Long
)

/** 播放记录：按视频地址保存进度，下次播放同一地址从上次位置继续 */
@Entity(tableName = "playback_positions")
data class PlaybackPosition(
    @PrimaryKey val url: String,
    val title: String,
    val positionMs: Long,
    val durationMs: Long,
    val updatedAt: Long
)

@Dao
interface HistoryDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: HistoryItem)

    /** 全部历史，按时间倒序 */
    @Query("SELECT * FROM history ORDER BY timestamp DESC")
    fun getAll(): Flow<List<HistoryItem>>

    /** 按标题或网址搜索 */
    @Query("SELECT * FROM history WHERE title LIKE '%' || :query || '%' OR url LIKE '%' || :query || '%' ORDER BY timestamp DESC")
    fun search(query: String): Flow<List<HistoryItem>>

    @Query("DELETE FROM history WHERE url = :url")
    suspend fun delete(url: String)

    @Query("DELETE FROM history")
    suspend fun deleteAll()
}

@Dao
interface BookmarkDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(bookmark: Bookmark)

    /** 全部书签，按时间倒序 */
    @Query("SELECT * FROM bookmarks ORDER BY timestamp DESC")
    fun getAll(): Flow<List<Bookmark>>

    /** 查某一个网址是否已收藏 */
    @Query("SELECT * FROM bookmarks WHERE url = :url LIMIT 1")
    fun observe(url: String): Flow<Bookmark?>

    @Query("DELETE FROM bookmarks WHERE url = :url")
    suspend fun delete(url: String)
}

@Dao
interface PlaybackDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: PlaybackPosition)

    /** 查某一个视频的保存进度 */
    @Query("SELECT * FROM playback_positions WHERE url = :url LIMIT 1")
    suspend fun get(url: String): PlaybackPosition?

    /** 全部播放记录，按最近更新倒序（播放入口页“继续播放”列表用） */
    @Query("SELECT * FROM playback_positions ORDER BY updatedAt DESC")
    fun getAll(): Flow<List<PlaybackPosition>>

    @Query("DELETE FROM playback_positions WHERE url = :url")
    suspend fun delete(url: String)
}

/** 数据库：video_browser.db，版本 2（v1→v2 只新增 playback_positions 表） */
@Database(
    entities = [HistoryItem::class, Bookmark::class, PlaybackPosition::class],
    version = 2,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
    abstract fun bookmarkDao(): BookmarkDao
    abstract fun playbackDao(): PlaybackDao
}
