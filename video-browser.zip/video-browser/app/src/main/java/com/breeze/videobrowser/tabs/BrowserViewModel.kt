package com.breeze.videobrowser.tabs

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.breeze.videobrowser.data.BrowserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

/**
 * 一个标签页的状态。
 * 注意：WebView 本身由 WebViewManager 管理，不放在这里，
 * 这里只保存标签页的网址、标题、进度等轻量状态（旋转屏幕也不丢失）。
 */
data class Tab(
    val id: String = UUID.randomUUID().toString(),
    val url: String = "",
    val title: String = "新标签页",
    val progress: Int = 100,
    val canGoBack: Boolean = false,
    val canGoForward: Boolean = false
)

class BrowserViewModel(private val repository: BrowserRepository) : ViewModel() {

    private val _tabs = MutableStateFlow(listOf(Tab()))
    val tabs: StateFlow<List<Tab>> = _tabs.asStateFlow()

    private val _currentTabId = MutableStateFlow(_tabs.value.first().id)
    val currentTabId: StateFlow<String> = _currentTabId.asStateFlow()

    /** 当前标签页（不存在时返回 null） */
    val currentTab: Tab?
        get() = _tabs.value.find { it.id == _currentTabId.value }

    /** 新建标签页，可选初始网址；默认切过去 */
    fun newTab(url: String = "", switchTo: Boolean = true) {
        val tab = Tab(url = url)
        _tabs.value = _tabs.value + tab
        if (switchTo) _currentTabId.value = tab.id
    }

    /** 关闭标签页；关到最后一个时自动新建一个空白页 */
    fun closeTab(id: String) {
        val list = _tabs.value
        if (list.size <= 1) {
            val tab = Tab()
            _tabs.value = listOf(tab)
            _currentTabId.value = tab.id
            return
        }
        val index = list.indexOfFirst { it.id == id }
        val newList = list.filterNot { it.id == id }
        _tabs.value = newList
        if (_currentTabId.value == id) {
            // 切到被关标签页相邻的一个
            val next = newList.getOrNull(index.coerceAtMost(newList.lastIndex))
            _currentTabId.value = next?.id ?: newList.first().id
        }
    }

    /** 切换到指定标签页 */
    fun switchTab(id: String) {
        if (_tabs.value.any { it.id == id }) _currentTabId.value = id
    }

    /** 更新指定标签页的网址（由 WebView 回调或地址栏触发） */
    fun updateTabUrl(id: String, url: String) {
        _tabs.value = _tabs.value.map { if (it.id == id) it.copy(url = url) else it }
    }

    /** 更新指定标签页的标题 */
    fun updateTabTitle(id: String, title: String) {
        if (title.isBlank()) return
        _tabs.value = _tabs.value.map { if (it.id == id) it.copy(title = title) else it }
    }

    /** 更新加载进度（0~100） */
    fun updateTabProgress(id: String, progress: Int) {
        _tabs.value = _tabs.value.map { if (it.id == id) it.copy(progress = progress) else it }
    }

    /** 更新前进 / 后退按钮状态 */
    fun updateTabNavState(id: String, canGoBack: Boolean, canGoForward: Boolean) {
        _tabs.value = _tabs.value.map {
            if (it.id == id) it.copy(canGoBack = canGoBack, canGoForward = canGoForward) else it
        }
    }
}

/** ViewModel 工厂：把仓库传给 ViewModel */
class BrowserViewModelFactory(
    private val repository: BrowserRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(BrowserViewModel::class.java)) {
            return BrowserViewModel(repository) as T
        }
        throw IllegalArgumentException("未知的 ViewModel 类型：${modelClass.name}")
    }
}
