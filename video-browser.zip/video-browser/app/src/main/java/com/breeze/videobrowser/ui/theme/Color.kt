package com.breeze.videobrowser.ui.theme

import androidx.compose.ui.graphics.Color

// 主题色：青色系
val TealPrimary = Color(0xFF00696D)
val TealPrimaryDark = Color(0xFF4DD0E1)
val TealSecondary = Color(0xFF4A6365)
val TealSecondaryDark = Color(0xFFB0CBCB)
val TealTertiary = Color(0xFF4A5F8A)
val TealTertiaryDark = Color(0xFFB8C8E8)
