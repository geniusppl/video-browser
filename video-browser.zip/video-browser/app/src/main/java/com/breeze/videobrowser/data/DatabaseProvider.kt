package com.breeze.videobrowser.data

import android.content.Context
import androidx.room.Room
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/** 数据库单例：整个应用共用一个实例 */
object DatabaseProvider {
    @Volatile
    private var instance: AppDatabase? = null

    /** v1→v2 迁移：只新增 playback_positions 表，历史和书签原样保留 */
    private val MIGRATION_1_2 = object : Migration(1, 2) {
        override fun migrate(db: SupportSQLiteDatabase) {
            db.execSQL(
                "CREATE TABLE IF NOT EXISTS `playback_positions` (" +
                    "`url` TEXT NOT NULL, `title` TEXT NOT NULL, " +
                    "`positionMs` INTEGER NOT NULL, `durationMs` INTEGER NOT NULL, " +
                    "`updatedAt` INTEGER NOT NULL, PRIMARY KEY(`url`))"
            )
        }
    }

    fun get(context: Context): AppDatabase {
        return instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "video_browser.db"
            ).addMigrations(MIGRATION_1_2).build().also { instance = it }
        }
    }
}
