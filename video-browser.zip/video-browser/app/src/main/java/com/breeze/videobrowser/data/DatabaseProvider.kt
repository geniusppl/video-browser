package com.breeze.videobrowser.data

import android.content.Context
import androidx.room.Room

/** 数据库单例：整个应用共用一个实例 */
object DatabaseProvider {
    @Volatile
    private var instance: AppDatabase? = null

    fun get(context: Context): AppDatabase {
        return instance ?: synchronized(this) {
            instance ?: Room.databaseBuilder(
                context.applicationContext,
                AppDatabase::class.java,
                "video_browser.db"
            ).build().also { instance = it }
        }
    }
}
