package com.breeze.videobrowser.player

import android.content.Context
import android.content.Intent
import android.content.pm.ActivityInfo
import android.media.AudioManager
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AspectRatio
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.breeze.videobrowser.data.BrowserRepository
import com.breeze.videobrowser.data.DatabaseProvider
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

/** 画面比例：适应 / 填充（裁剪铺满）/ 拉伸 / 16:9 / 4:3 */
private enum class AspectMode(val label: String) {
    FIT("适应"),
    FILL("填充"),
    STRETCH("拉伸"),
    RATIO_16_9("16:9"),
    RATIO_4_3("4:3")
}

/** 倍速档位 */
private val SPEEDS = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f, 3.0f)

/** 格式化时间：毫秒 → 01:23 / 01:02:03 */
fun formatPlayerTime(ms: Long): String {
    if (ms < 0) return "00:00"
    val totalSec = ms / 1000
    val h = totalSec / 3600
    val m = (totalSec % 3600) / 60
    val s = totalSec % 60
    return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%02d:%02d".format(m, s)
}

/**
 * 全屏视频播放页（提示词二）。
 * Media3 ExoPlayer，支持 mp4 / m3u8（HLS）/ mpd（DASH）地址和本地视频文件。
 * 横屏优先（左右横屏间随手机旋转），支持自动旋转。
 */
class VideoPlayerActivity : ComponentActivity() {

    companion object {
        private const val EXTRA_URL = "url"
        private const val EXTRA_TITLE = "title"
        private const val EXTRA_IS_LOCAL = "is_local"

        /** 播放入口：url 可以是 http(s) 地址，也可以是本地文件的 content:// Uri 字符串 */
        fun createIntent(context: Context, url: String, title: String, isLocal: Boolean): Intent {
            return Intent(context, VideoPlayerActivity::class.java).apply {
                putExtra(EXTRA_URL, url)
                putExtra(EXTRA_TITLE, title)
                putExtra(EXTRA_IS_LOCAL, isLocal)
                if (isLocal) addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
        }
    }

    private var player: ExoPlayer? = null
    private lateinit var repository: BrowserRepository
    private var videoUrl: String = ""
    private var videoTitle: String = ""
    private var isLocal: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // 横屏优先：左右横屏之间随手机旋转
        requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
        // 全屏沉浸：隐藏状态栏和导航栏
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }

        videoUrl = intent.getStringExtra(EXTRA_URL).orEmpty()
        videoTitle = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        isLocal = intent.getBooleanExtra(EXTRA_IS_LOCAL, false)
        if (videoTitle.isBlank()) {
            videoTitle = if (isLocal) localFileName(videoUrl) else Uri.parse(videoUrl).lastPathSegment ?: videoUrl
        }

        val database = DatabaseProvider.get(applicationContext)
        repository = BrowserRepository(database.historyDao(), database.bookmarkDao(), database.playbackDao())

        player = ExoPlayer.Builder(this).build().apply {
            // MediaItem 会按地址后缀自动选源：mp4 / HLS(.m3u8) / DASH(.mpd)
            setMediaItem(MediaItem.fromUri(Uri.parse(videoUrl)))
            prepare()
            playWhenReady = true
        }

        setContent {
            PlayerScreen(
                player = player!!,
                title = videoTitle,
                urlKey = videoUrl,
                repository = repository,
                onExit = { finish() },
                onSavePosition = { pos, dur -> savePosition(pos, dur) }
            )
        }
    }

    /** 查本地视频的文件名（content:// Uri 用 ContentResolver 读 DISPLAY_NAME） */
    private fun localFileName(uriString: String): String {
        return try {
            val uri = Uri.parse(uriString)
            if (uri.scheme == "content") {
                contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (idx >= 0) return cursor.getString(idx) ?: uri.lastPathSegment.orEmpty()
                    }
                }
            }
            uri.lastPathSegment.orEmpty()
        } catch (_: Exception) {
            uriString.substringAfterLast('/').ifBlank { "本地视频" }
        }
    }

    /** 保存进度：只在有意义的位置保存，播完不保存（下次从头播） */
    private fun savePosition(positionMs: Long, durationMs: Long) {
        if (videoUrl.isBlank()) return
        lifecycleScope.launch {
            try {
                repository.savePlaybackPosition(videoUrl, videoTitle, positionMs, durationMs)
            } catch (_: Exception) {
                // 保存失败不影响播放，不弹错
            }
        }
    }

    override fun onPause() {
        super.onPause()
        player?.let { savePosition(it.currentPosition, it.duration.coerceAtLeast(0)) }
    }

    override fun onDestroy() {
        player?.let { savePosition(it.currentPosition, it.duration.coerceAtLeast(0)) }
        player?.release()
        player = null
        super.onDestroy()
    }
}

/** 手势拖动模式 */
private enum class DragMode { NONE, SEEK, BRIGHTNESS, VOLUME }

/** 播放页界面：PlayerView + 自绘控制层 + 手势层 */
@Composable
private fun PlayerScreen(
    player: ExoPlayer,
    title: String,
    urlKey: String,
    repository: BrowserRepository,
    onExit: () -> Unit,
    onSavePosition: (Long, Long) -> Unit
) {
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    val audioManager = remember {
        context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    }
    val scope = rememberCoroutineScope()

    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var isPlaying by remember { mutableStateOf(false) }
    var controlsVisible by remember { mutableStateOf(true) }
    var locked by remember { mutableStateOf(false) }
    var speed by remember { mutableFloatStateOf(1.0f) }
    var speedMenuOpen by remember { mutableStateOf(false) }
    var aspectMenuOpen by remember { mutableStateOf(false) }
    var aspect by remember { mutableStateOf(AspectMode.FIT) }
    var errorMessage by remember { mutableStateOf<String?>(null) }
    var resumedText by remember { mutableStateOf<String?>(null) }
    var indicatorText by remember { mutableStateOf<String?>(null) }
    var seekPreviewMs by remember { mutableLongStateOf(-1L) }
    var sliderDragging by remember { mutableStateOf(false) }
    var sliderValue by remember { mutableFloatStateOf(0f) }
    var boxSize by remember { mutableStateOf(IntSize.Zero) }
    // 长按加速用：记下长按前的倍速，松开恢复
    var speedBeforeLongPress by remember { mutableFloatStateOf(1.0f) }
    var longPressActive by remember { mutableStateOf(false) }
    var savedPositionLoaded by remember { mutableStateOf(false) }

    // 监听播放器：出错时显示错误页；首次就绪时恢复上次进度
    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onPlayerError(error: PlaybackException) {
                errorMessage = when (error.errorCode) {
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
                    PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT ->
                        "网络错误，视频加载失败，请检查网络后重试"
                    PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
                        "找不到这个视频文件"
                    PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
                    PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
                        "这个视频格式不支持播放"
                    else -> "播放出错：${error.message ?: "未知错误"}"
                }
            }

            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY && !savedPositionLoaded) {
                    savedPositionLoaded = true
                    scope.launch {
                        val saved = try {
                            repository.getPlaybackPosition(urlKey)
                        } catch (_: Exception) {
                            null
                        }
                        if (saved != null && saved.positionMs > 5_000) {
                            val dur = player.duration.coerceAtLeast(0)
                            if (dur <= 0 || saved.positionMs < dur - 5_000) {
                                player.seekTo(saved.positionMs)
                                resumedText = "已从上次位置继续 ${formatPlayerTime(saved.positionMs)}"
                            }
                        }
                    }
                }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener) }
    }

    // 每 500ms 刷新进度 / 播放状态；每 10 秒自动存一次进度
    LaunchedEffect(player) {
        var ticks = 0
        while (true) {
            positionMs = player.currentPosition
            durationMs = player.duration.coerceAtLeast(0)
            isPlaying = player.isPlaying
            ticks++
            if (ticks % 20 == 0 && positionMs > 5_000) {
                onSavePosition(positionMs, durationMs)
            }
            delay(500)
        }
    }

    // 播放中 3 秒无操作自动隐藏控制层
    LaunchedEffect(controlsVisible, isPlaying) {
        if (controlsVisible && isPlaying && !locked) {
            delay(3000)
            controlsVisible = false
        }
    }
    // “已从上次位置继续”提示 4 秒后消失
    LaunchedEffect(resumedText) {
        if (resumedText != null) {
            delay(4000)
            resumedText = null
        }
    }
    // 手势提示（亮度 / 音量 / 快进预览）1 秒后消失
    LaunchedEffect(indicatorText) {
        if (indicatorText != null) {
            delay(1000)
            indicatorText = null
        }
    }

    BackHandler {
        // 退出前先存进度
        onSavePosition(player.currentPosition, player.duration.coerceAtLeast(0))
        onExit()
    }

    // 手势状态（拖动起点、累计位移、基准值）
    var dragMode by remember { mutableStateOf(DragMode.NONE) }
    var dragStart by remember { mutableStateOf(Offset.Zero) }
    var dragTotal by remember { mutableStateOf(Offset.Zero) }
    var dragBasePosition by remember { mutableLongStateOf(0L) }
    var dragBaseBrightness by remember { mutableFloatStateOf(0.5f) }
    var dragBaseVolume by remember { mutableStateOf(0) }

    fun showControls() {
        controlsVisible = true
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
            .onSizeChanged { boxSize = it }
    ) {
        // 视频画面：PlayerView（自带画面），不用它自带的控制条
        val videoModifier = when (aspect) {
            AspectMode.RATIO_16_9 -> Modifier.aspectRatio(16f / 9f)
            AspectMode.RATIO_4_3 -> Modifier.aspectRatio(4f / 3f)
            else -> Modifier.fillMaxSize()
        }
        Box(
            modifier = Modifier.fillMaxSize(),
            contentAlignment = Alignment.Center
        ) {
            AndroidView(
                factory = { ctx ->
                    PlayerView(ctx).apply {
                        this.player = player
                        useController = false
                        resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                    }
                },
                update = { view ->
                    view.resizeMode = when (aspect) {
                        AspectMode.FIT, AspectMode.RATIO_16_9, AspectMode.RATIO_4_3 ->
                            AspectRatioFrameLayout.RESIZE_MODE_FIT
                        AspectMode.FILL -> AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                        AspectMode.STRETCH -> AspectRatioFrameLayout.RESIZE_MODE_FILL
                    }
                },
                modifier = videoModifier
            )
        }

        // 手势层：未锁定时才响应（锁定时只留右上角解锁按钮）
        if (!locked) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .pointerInput(Unit) {
                        detectTapGestures(
                            onTap = { showControls() },
                            onDoubleTap = {
                                if (player.isPlaying) player.pause() else player.play()
                                showControls()
                            },
                            onLongPress = {
                                // 长按两倍速：记下当前倍速再加速
                                if (!longPressActive) {
                                    speedBeforeLongPress = speed
                                    speed = 2.0f
                                    player.setPlaybackSpeed(2.0f)
                                    longPressActive = true
                                    indicatorText = "2.0x 快进中"
                                }
                            },
                            onPress = {
                                // 松开手指时，若刚才在长按加速，恢复原来倍速
                                val released = tryAwaitRelease()
                                if (released && longPressActive) {
                                    speed = speedBeforeLongPress
                                    player.setPlaybackSpeed(speedBeforeLongPress)
                                    longPressActive = false
                                }
                            }
                        )
                    }
                    .pointerInput(Unit) {
                        detectDragGestures(
                            onDragStart = { offset ->
                                dragMode = DragMode.NONE
                                dragStart = offset
                                dragTotal = Offset.Zero
                                dragBasePosition = player.currentPosition
                                val attrs = activity?.window?.attributes
                                dragBaseBrightness = attrs?.screenBrightness?.takeIf { it >= 0f } ?: 0.5f
                                dragBaseVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                            },
                            onDragEnd = {
                                if (dragMode == DragMode.SEEK && seekPreviewMs >= 0) {
                                    player.seekTo(seekPreviewMs)
                                    positionMs = seekPreviewMs
                                }
                                dragMode = DragMode.NONE
                                seekPreviewMs = -1L
                                showControls()
                            },
                            onDragCancel = {
                                dragMode = DragMode.NONE
                                seekPreviewMs = -1L
                            },
                            onDrag = { _, dragAmount ->
                                dragTotal += dragAmount
                                val width = boxSize.width.coerceAtLeast(1)
                                val height = boxSize.height.coerceAtLeast(1)
                                if (dragMode == DragMode.NONE) {
                                    if (abs(dragTotal.x) > 20 || abs(dragTotal.y) > 20) {
                                        dragMode = if (abs(dragTotal.x) > abs(dragTotal.y)) {
                                            DragMode.SEEK
                                        } else if (dragStart.x < width / 2) {
                                            DragMode.BRIGHTNESS
                                        } else {
                                            DragMode.VOLUME
                                        }
                                    } else {
                                        return@detectDragGestures
                                    }
                                }
                                when (dragMode) {
                                    DragMode.SEEK -> {
                                        val dur = durationMs.coerceAtLeast(1)
                                        val preview = (dragBasePosition + dragTotal.x / width * dur)
                                            .toLong().coerceIn(0, dur)
                                        seekPreviewMs = preview
                                        indicatorText = "${formatPlayerTime(preview)} / ${formatPlayerTime(dur)}"
                                    }
                                    DragMode.BRIGHTNESS -> {
                                        val value = (dragBaseBrightness - dragTotal.y / height)
                                            .coerceIn(0.01f, 1f)
                                        activity?.window?.let { win ->
                                            val attrs = win.attributes
                                            attrs.screenBrightness = value
                                            win.attributes = attrs
                                        }
                                        indicatorText = "亮度 ${(value * 100).toInt()}%"
                                    }
                                    DragMode.VOLUME -> {
                                        val max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                        val value = (dragBaseVolume - dragTotal.y / height * max)
                                            .toInt().coerceIn(0, max)
                                        audioManager.setStreamVolume(
                                            AudioManager.STREAM_MUSIC, value, 0
                                        )
                                        indicatorText = "音量 ${(value * 100 / max.coerceAtLeast(1))}%"
                                    }
                                    DragMode.NONE -> {}
                                }
                            }
                        )
                    }
            )
        }

        // 锁定时：右上角只留一个解锁按钮
        if (locked) {
            IconButton(
                onClick = { locked = false; showControls() },
                modifier = Modifier.align(Alignment.TopEnd).padding(12.dp)
            ) {
                Icon(Icons.Filled.Lock, contentDescription = "解锁", tint = Color.White)
            }
            // 锁定时点画面中央也提示已锁定（不触发播放/暂停）
            Box(
                modifier = Modifier.fillMaxSize().pointerInput(Unit) {
                    detectTapGestures(onTap = { indicatorText = "已锁定，点右上角解锁" })
                }
            )
        }

        // 手势提示 / 恢复提示（画面中央上方）
        if (indicatorText != null || resumedText != null) {
            Box(
                modifier = Modifier.align(Alignment.TopCenter).padding(top = 48.dp)
                    .background(Color.Black.copy(alpha = 0.6f), RoundedCornerShape(8.dp))
                    .padding(horizontal = 16.dp, vertical = 8.dp)
            ) {
                Text(
                    text = resumedText ?: indicatorText.orEmpty(),
                    color = Color.White,
                    fontSize = 15.sp
                )
            }
        }

        // 暂停时中央大播放按钮
        if (!isPlaying && errorMessage == null && !locked) {
            IconButton(
                onClick = { player.play(); showControls() },
                modifier = Modifier.align(Alignment.Center).size(72.dp)
            ) {
                Icon(
                    Icons.Filled.PlayArrow,
                    contentDescription = "播放",
                    tint = Color.White,
                    modifier = Modifier.size(64.dp)
                )
            }
        }

        // 出错页：明确提示 + 重试按钮
        if (errorMessage != null) {
            Column(
                modifier = Modifier.align(Alignment.Center).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    Icons.Filled.ErrorOutline,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(text = errorMessage.orEmpty(), color = Color.White, fontSize = 15.sp)
                Spacer(modifier = Modifier.height(16.dp))
                Button(onClick = {
                    errorMessage = null
                    player.prepare()
                    player.play()
                }) {
                    Icon(Icons.Filled.Refresh, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("重试")
                }
                Spacer(modifier = Modifier.height(8.dp))
                TextButton(onClick = onExit) { Text("返回", color = Color.White) }
            }
        }

        // 控制层：顶部标题栏 + 底部进度/按钮（3 秒无操作自动隐藏）
        if (controlsVisible && !locked && errorMessage == null) {
            // 顶部：返回 + 标题 + 锁屏
            Row(
                modifier = Modifier.align(Alignment.TopStart).fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.4f))
                    .padding(horizontal = 4.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = {
                    onSavePosition(player.currentPosition, player.duration.coerceAtLeast(0))
                    onExit()
                }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "返回", tint = Color.White)
                }
                Text(
                    text = title,
                    color = Color.White,
                    fontSize = 15.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f)
                )
                IconButton(onClick = { locked = true; controlsVisible = false }) {
                    Icon(Icons.Filled.LockOpen, contentDescription = "锁屏", tint = Color.White)
                }
            }

            // 底部：进度条 + 时间 + 播放暂停 + 倍速 + 画面比例
            Column(
                modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(Color.Black.copy(alpha = 0.4f))
                    .padding(horizontal = 12.dp, vertical = 8.dp)
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = formatPlayerTime(if (seekPreviewMs >= 0) seekPreviewMs else positionMs),
                        color = Color.White,
                        fontSize = 13.sp
                    )
                    Slider(
                        value = if (sliderDragging) sliderValue else {
                            if (durationMs > 0) positionMs.toFloat() / durationMs else 0f
                        },
                        onValueChange = {
                            sliderDragging = true
                            sliderValue = it
                            seekPreviewMs = (it * durationMs).toLong()
                            indicatorText = "${formatPlayerTime(seekPreviewMs)} / ${formatPlayerTime(durationMs)}"
                        },
                        onValueChangeFinished = {
                            sliderDragging = false
                            if (seekPreviewMs >= 0) {
                                player.seekTo(seekPreviewMs)
                                positionMs = seekPreviewMs
                            }
                            seekPreviewMs = -1L
                        },
                        modifier = Modifier.weight(1f)
                    )
                    Text(
                        text = formatPlayerTime(durationMs),
                        color = Color.White,
                        fontSize = 13.sp
                    )
                }
                Row(
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    IconButton(onClick = {
                        if (player.isPlaying) player.pause() else player.play()
                        showControls()
                    }) {
                        Icon(
                            if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                            contentDescription = if (isPlaying) "暂停" else "播放",
                            tint = Color.White
                        )
                    }
                    // 倍速按钮：点开选 0.5–3.0
                    Box {
                        TextButton(onClick = { speedMenuOpen = true }) {
                            Text("${speed}x", color = Color.White, fontSize = 15.sp)
                        }
                        DropdownMenu(
                            expanded = speedMenuOpen,
                            onDismissRequest = { speedMenuOpen = false }
                        ) {
                            SPEEDS.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(if (s == 1.0f) "1.0x（正常）" else "${s}x") },
                                    onClick = {
                                        speed = s
                                        player.setPlaybackSpeed(s)
                                        speedMenuOpen = false
                                        showControls()
                                    }
                                )
                            }
                        }
                    }
                    // 画面比例按钮：适应 / 填充 / 拉伸 / 16:9 / 4:3
                    Box {
                        TextButton(onClick = { aspectMenuOpen = true }) {
                            Icon(Icons.Filled.AspectRatio, contentDescription = null, tint = Color.White)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(aspect.label, color = Color.White, fontSize = 15.sp)
                        }
                        DropdownMenu(
                            expanded = aspectMenuOpen,
                            onDismissRequest = { aspectMenuOpen = false }
                        ) {
                            AspectMode.entries.forEach { mode ->
                                DropdownMenuItem(
                                    text = { Text(mode.label) },
                                    onClick = {
                                        aspect = mode
                                        aspectMenuOpen = false
                                        showControls()
                                    }
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
