package com.breeze.videobrowser.webview

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import com.breeze.videobrowser.data.BrowserRepository
import com.breeze.videobrowser.tabs.BrowserViewModel
import com.breeze.videobrowser.tabs.Tab
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.launch

/**
 * 管理各标签页的 WebView 实例。
 * 每个标签页一个 WebView，保存在 map 里，切换标签时复用，不重建。
 * 注意：WebView 持有 Activity 的 Context，随 Activity 销毁而销毁，不做跨 Activity 缓存。
 */
class WebViewManager(
    private val context: Context,
    private val viewModel: BrowserViewModel,
    private val repository: BrowserRepository,
    private val scope: CoroutineScope,
    private val onFullscreenChanged: (Boolean) -> Unit
) {
    // 标签页 id → WebView
    private val webViews = mutableMapOf<String, WebView>()

    // 网页视频全屏相关
    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var fullscreenClient: WebChromeClient? = null

    /** 是否正处于网页视频全屏 */
    var isFullscreen: Boolean = false
        private set

    /** 取指定标签页的 WebView，没有就新建 */
    fun getWebView(tab: Tab): WebView {
        return webViews.getOrPut(tab.id) { createWebView(tab) }
    }

    /** 当前标签页的 WebView（还没创建过时返回 null） */
    fun currentWebView(): WebView? {
        val tab = viewModel.currentTab ?: return null
        return webViews[tab.id]
    }

    /** 在当前标签页打开输入内容（网址或搜索关键词） */
    fun navigateCurrent(rawInput: String) {
        val tab = viewModel.currentTab ?: return
        val url = resolveInputToUrl(rawInput)
        if (url.isEmpty()) return
        viewModel.updateTabUrl(tab.id, url)
        getWebView(tab).loadUrl(url)
    }

    /** 在指定标签页打开网址（用于从历史 / 书签点开） */
    fun openUrlInTab(tab: Tab, url: String) {
        viewModel.updateTabUrl(tab.id, url)
        getWebView(tab).loadUrl(url)
    }

    /** 退出网页视频全屏（供返回键调用） */
    fun hideCustomView() {
        fullscreenClient?.onHideCustomView()
    }

    /** 销毁某个标签页的 WebView（关闭标签页时调用） */
    fun removeTabWebView(id: String) {
        webViews.remove(id)?.let { webView ->
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        }
    }

    /** 销毁全部 WebView（界面销毁时调用） */
    fun destroy() {
        webViews.values.forEach { webView ->
            (webView.parent as? ViewGroup)?.removeView(webView)
            webView.destroy()
        }
        webViews.clear()
    }

    private fun createWebView(tab: Tab): WebView {
        return WebView(context).apply {
            // JavaScript 和 DOM 存储必须开，否则大部分网页无法正常使用
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.databaseEnabled = true
            settings.useWideViewPort = true
            settings.loadWithOverviewMode = true
            settings.builtInZoomControls = true
            settings.displayZoomControls = false
            // 允许 https 页面加载 http 子资源，避免部分页面图片 / 视频打不开
            settings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
            CookieManager.getInstance().setAcceptCookie(true)

            webViewClient = object : WebViewClient() {
                override fun onPageStarted(view: WebView, url: String?, favicon: Bitmap?) {
                    url?.let { viewModel.updateTabUrl(tab.id, it) }
                }

                override fun onPageFinished(view: WebView, url: String?) {
                    viewModel.updateTabNavState(tab.id, view.canGoBack(), view.canGoForward())
                    val title = view.title
                    if (!url.isNullOrBlank() && url.startsWith("http") && !title.isNullOrBlank()) {
                        // 页面加载完成且有标题时，记一条历史
                        scope.launch { repository.addHistory(url, title) }
                    }
                }

                override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                    val url = request.url.toString()
                    return if (url.startsWith("http://") || url.startsWith("https://")) {
                        false // http(s) 链接交给 WebView 自己打开
                    } else {
                        // tel:、mailto: 等外部链接交给系统处理
                        try {
                            context.startActivity(Intent(Intent.ACTION_VIEW, request.url))
                        } catch (_: Exception) {
                            // 没有能处理的应用时忽略
                        }
                        true
                    }
                }
            }

            val chromeClient = object : WebChromeClient() {
                override fun onProgressChanged(view: WebView, newProgress: Int) {
                    viewModel.updateTabProgress(tab.id, newProgress)
                }

                override fun onReceivedTitle(view: WebView, title: String?) {
                    title?.let { viewModel.updateTabTitle(tab.id, it) }
                }

                override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                    // 已有全屏视图时，先把旧的关掉
                    if (customView != null) {
                        callback?.onCustomViewHidden()
                        return
                    }
                    // 系统没给视图时直接拒绝，避免空指针闪退
                    val custom = view ?: run {
                        callback?.onCustomViewHidden()
                        return
                    }
                    customView = custom
                    customViewCallback = callback
                    fullscreenClient = this
                    val activity = context as? Activity
                    activity?.let {
                        val decor = it.window.decorView as ViewGroup
                        decor.addView(
                            custom,
                            ViewGroup.LayoutParams(
                                ViewGroup.LayoutParams.MATCH_PARENT,
                                ViewGroup.LayoutParams.MATCH_PARENT
                            )
                        )
                        // 隐藏状态栏和导航栏，进入沉浸全屏
                        WindowCompat.getInsetsController(it.window, it.window.decorView)
                            .hide(WindowInsetsCompat.Type.systemBars())
                    }
                    isFullscreen = true
                    onFullscreenChanged(true)
                }

                override fun onHideCustomView() {
                    customView?.let { view ->
                        val activity = context as? Activity
                        activity?.let {
                            (it.window.decorView as ViewGroup).removeView(view)
                            WindowCompat.getInsetsController(it.window, it.window.decorView)
                                .show(WindowInsetsCompat.Type.systemBars())
                        }
                    }
                    customView = null
                    customViewCallback?.onCustomViewHidden()
                    customViewCallback = null
                    fullscreenClient = null
                    isFullscreen = false
                    onFullscreenChanged(false)
                }
            }
            webChromeClient = chromeClient

            if (tab.url.isNotBlank()) {
                loadUrl(tab.url)
            }
        }
    }
}
